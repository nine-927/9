﻿/* =====================================================================
 *  俄罗斯方块 · 第 2 步:让方块动起来,而且不留残影
 * ---------------------------------------------------------------------
 *  关键点:
 *   1) 给方块一个坐标 (x, y)。x 是第几列,y 是第几行。
 *      x 变大 => 往右,y 变大 => 往下。
 *   2) 终端里 printf 只会从光标处往后写,不会回头擦字。
 *      所以所谓的"擦",其实就是"用空格把原来的位置重新盖一遍"。
 *   3) 每一帧固定两个动作:先擦掉旧位置 -> 再画在新位置。
 *      这样方块身后就不会留下拖尾(残影)。
 *
 *  用到的 Windows 函数:
 *   - SetConsoleCursorPosition():把光标直接挪到指定的行列,不用换行。
 *   - Sleep():暂停若干毫秒,用来控制移动速度。
 * ===================================================================== */
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#define ROWS 2
#define COLS 2

/* 方块形状:2x2 全填满,也就是俄罗斯方块里的 "O" 形 */
int shape[ROWS][COLS] = {
    { 1, 1 },
    { 1, 1 }
};

/* 把光标移到终端的第 y 行、第 x 列(左上角是 0 行 0 列) */
static void gotoxy(int x, int y)
{
    COORD pos;
    pos.X = (SHORT)x;
    pos.Y = (SHORT)y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

/*
 * 在"格坐标" (gx, gy) 处绘制方块。
 * erased = 0 画方块 "[]",erased = 1 用空格把它擦掉。
 * 注意:一个格子占终端 2 列宽,所以列坐标要乘 2。
 */
static void paint(int gx, int gy, int erased)
{
    int r, c;

    for (r = 0; r < ROWS; r++) {
        for (c = 0; c < COLS; c++) {
            if (shape[r][c] == 1) {
                gotoxy((gx + c) * 2, gy + r);
                printf(erased ? "  " : "[]");
            }
        }
    }
}

int main(void)
{
    int x;

    system("chcp 65001 > nul");      /* 让终端能正常显示中文 */

    for (x = 0; x <= 20; x++) {

        if (x > 0) {
            paint(x - 1, 5, 1);      /* 第一步:擦掉上一帧 */
        }
        paint(x, 5, 0);              /* 第二步:画在这一帧的位置 */

        Sleep(120);                  /* 歇 120 毫秒,不然快到看不清 */
    }

    gotoxy(0, 9);
    printf("移动完成,方块身后没有残影。\n");

    return 0;
}
